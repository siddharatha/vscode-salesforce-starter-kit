export http_proxy=
export https_proxy=
export HTTP_PROXY=
export HTTPS_PROXY=
set http_proxy=
set https_proxy=
set HTTP_PROXY=
set HTTPS_PROXY=
npm config delete proxy
npm config delete https-proxy
git config --global --unset http.proxy
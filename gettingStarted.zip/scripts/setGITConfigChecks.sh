git config --global core.safecrlf false
git config --global core.autocrlf false
git config --global diff.algorithm patience
git config --global merge.conflictstyle diff3
export http_proxy=http://205.167.7.126:80/
export https_proxy=http://205.167.7.126:80/
export HTTP_PROXY=http://205.167.7.126:80/
export HTTPS_PROXY=http://205.167.7.126:80/
set http_proxy=http://205.167.7.126:80/
set https_proxy=http://205.167.7.126:80/
set HTTP_PROXY=http://205.167.7.126:80/
set HTTPS_PROXY=http://205.167.7.126:80/
npm config set proxy='http://205.167.7.126:80/'
npm config set https-proxy='http://205.167.7.126:80/'
git config --global http.proxy 205.167.7.126:80